//this program simulates a tic tac toe game
package tictactoe;

/**
 *
 * @author Rodrigo Mozo Jr
 */
import java.util.Scanner;

public class TicTacToe {

    public static void main(String[] args) {
        char[][] table = createEmptyBoard();
        char currentPlayer = 'X';
        int move;

        // draw the board
        displayBoard(table);

        Scanner scnr = new Scanner(System.in);

        // overall game loop for player moves and checking for conditions to determine outcome of the game
        while (true) {
            // scan the player's move
            move = getPlayerMove(scnr, table, currentPlayer);

            // execute the players move
            makeMove(table, move, currentPlayer);

            // display the board eahc time something happens
            displayBoard(table);

            // check for a win or a tie
            if (checkWin(table, currentPlayer)) {
                System.out.println("Player " + currentPlayer + " wins!");
                break;
            } else if (checkTie(table)) {
                System.out.println("It's a tie!");
                break;
            }

            // switch players
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }

        
    }

    //method for creating the original board
    private static char[][] createEmptyBoard() {
        char[][] table = new char[17][17];

        // fill spaces in each grid
        for (int i = 0; i < 17; i++) {
            for (int j = 0; j < 17; j++) {
                table[i][j] = ' ';
            }
        }

        // draw the grid lines
        for (int i = 0; i < 17; i++) {
            table[5][i] = '-';
            table[11][i] = '-';
            table[i][5] = '|';
            table[i][11] = '|';
        }

        // put numbers in each space so players can know what space is what
        table[2][2] = '1';
        table[2][8] = '2';
        table[2][14] = '3';
        table[8][2] = '4';
        table[8][8] = '5';
        table[8][14] = '6';
        table[14][2] = '7';
        table[14][8] = '8';
        table[14][14] = '9';

        return table;
    }

    //method for the gameboard
    private static void displayBoard(char[][] table) {
        for (int i = 0; i < 17; i++) {
            for (int j = 0; j < 17; j++) {
                System.out.print(table[i][j] + " ");
            }
            System.out.println();
        }
    }

    //method to check if player move is okay and store it to be used in makeMove
    private static int getPlayerMove(Scanner scnr, char[][] table, char currentPlayer) {
        int move;

        while (true) {
            System.out.print("Player " + currentPlayer + ", pick a space (1-9): ");
            move = scnr.nextInt();
            if (move >= 1 && move <= 9) {
            // calculate the appropriate row and column for the move
            int row = ((move - 1) / 3) * 6 + 2;
            int col = ((move - 1) % 3) * 6 + 2;

            // check if the space is free
            if (Character.isDigit(table[row][col])) {
                break;
            } else {
                System.out.println("Invalid move. That space is already being used. Try again.");
            }
        } else {
            System.out.println("Invalid move. Please choose a number between 1 and 9.");
        }
    }

    return move;
}

    //method to execute the players move
    private static void makeMove(char[][] table, int move, char currentPlayer) {
        // calculate the appropriate row and column for the move
        int row = (move - 1) / 3 * 6 + 2;
        int col = ((move - 1) % 3) * 6 + 2;

        // replace space with either x or o
        table[row][col] = currentPlayer;
    }

    //method to check for win
    private static boolean checkWin(char[][] table, char currentPlayer) {
        // check each possible way for a win
        for (int i = 2; i <= 14; i += 6) {
            if ((table[i][2] == currentPlayer && table[i][8] == currentPlayer && table[i][14] == currentPlayer) ||
                (table[2][i] == currentPlayer && table[8][i] == currentPlayer && table[14][i] == currentPlayer)) {
                return true;
            }
        }

        if ((table[2][2] == currentPlayer && table[8][8] == currentPlayer && table[14][14] == currentPlayer) ||
            (table[2][14] == currentPlayer && table[8][8] == currentPlayer && table[14][2] == currentPlayer)) {
            return true;
        }

        return false;
    }

    //method to check for tie
    private static boolean checkTie(char[][] table) {
        // check if all spaces are filled and nobody has three in a row
        for (int i = 2; i <= 14; i += 6) {
            for (int j = 2; j <= 14; j += 6) {
                if (Character.isDigit(table[i][j])) {
                    return false;
                }
            }
        }
        return true;
    }
}

