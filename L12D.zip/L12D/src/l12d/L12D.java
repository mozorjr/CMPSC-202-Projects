
package l12d;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;


public class L12D {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        File inFile = new File("palin.txt");
        Scanner fileInput=null;
        
        int a = 0;
        
        
        try{
            fileInput = new Scanner(inFile);
        }
            catch (FileNotFoundException e)
            {
                System.out.println(e);
                }
        Scanner scnr = new Scanner(System.in);
    
        for(a = 0; a!=7; a++){
    int i;
    int j = 0;
    //get input
    System.out.println("Enter a phrase");
    String word1Input = fileInput.nextLine();
   String word1Change = word1Input;
    //output the original phrase
    word1Input = word1Input.toLowerCase();
    //make lower case
    //eliminate punctuation
 
    String word1= "";
  //use a loop to create word1, which is your original phrase without punctuation
    
      int length = word1Input.length();
      for (i = 0; i<length; i++){
         if((word1Input.charAt(j)>='a')&&(word1Input.charAt(j)<='z')){
            word1 = word1+ word1Input.charAt(j);
            
      }
      j++;
      

      }
      
      
      String word2 = "";
      int f;
      
      for(f = word1.length()-1; f>=0; f--){
         word2 = word2 + word1.charAt(f);
      }
        
     if( word2.equals(word1)){
      System.out.println('"'+word1Change+'"'+" is a palindrome");
     }
      else{
      System.out.println('"'+word1Change+'"'+" is not a palindrome");
      }
        }
        
        
        
    }//clas
    
}//main
