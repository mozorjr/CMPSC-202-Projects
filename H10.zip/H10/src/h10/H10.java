//this program simulates 4 people selling 5 different kinds of flowers and the flowers sold are randomized. the data is shown in table and text form.

package h10;
//import code for randomizer
import java.util.Random;
/**
 *
 * @author Rodrigo Mozo Jr
 */
public class H10 {

    
    public static void main(String[] args) {
        String[] flowerTypes = {"petunia", "pansy", "rose", "violet", "carnation"};
        String[] people = {"Rodrigo", "Nayeli", "Natalia", "Xavier"};

        int[][] flowerSales = new int[4][5];

        // make random flower sales and declare random class
        Random random = new Random();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                flowerSales[i][j] = random.nextInt(21); // Generating random numbers between 0 and 20
            }
        }

        // print the sales 
        System.out.printf("%-10s%-10s%-10s%-10s%-10s%-10s\n", "", flowerTypes[0], flowerTypes[1], flowerTypes[2], flowerTypes[3], flowerTypes[4]);
        for (int i = 0; i < 4; i++) {
            System.out.printf("%-10s", people[i]);
            for (int j = 0; j < 5; j++) {
                System.out.printf("%-10d", flowerSales[i][j]);
            }
            System.out.println();
        }

        // calculate and print total sales for each person in the list
        System.out.println("\nIndividual Sales:");
        for (int i = 0; i < 4; i++) {
            int totalSales = 0;
            for (int j = 0; j < 5; j++) {
                totalSales += flowerSales[i][j];
            }
            System.out.printf("%s sold %d flowers\n", people[i], totalSales);
        }

        // calculate and print total sales for each flower 
        System.out.println("\nTotal Sales by Flower Type:");
        for (int j = 0; j < 5; j++) {
            int totalFlowerTypeSales = 0;
            for (int i = 0; i < 4; i++) {
                totalFlowerTypeSales += flowerSales[i][j];
            }
            System.out.printf("Total number of %s sold: %d\n", flowerTypes[j], totalFlowerTypeSales);
        }
    }//main
    
}//class
