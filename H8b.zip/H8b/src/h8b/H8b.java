/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package h8b;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;



/**
 *
 * @author mozor
 */
public class H8b {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //import file 
         File inFile = new File("words_no_duplicates.txt");
        Scanner fileInput =null;
        
        try{
            fileInput = new Scanner(inFile);
        }
        catch (FileNotFoundException e)
        { System.out.println(e);
            
        }
        //checking to make sure the file is read correctly before generating a number and printing the word
        
            Random random = new Random();
            int randomNum = random.nextInt(4581) + 1;
            String word = "";
            //make a for loop so that way it can look for the random number generated in the file full of words
            for (int k = 0; k < randomNum; k++) {
                if (fileInput.hasNext()) {
                    word = fileInput.next();
                } else {
                    break;
                }
            }
        //declare scanner and variables
        Scanner scnr = new Scanner(System.in);
        int numberWrong = 0;
        System.out.println("You are going to have 10 guesses/tries to guess the word.");
        System.out.println("Enter a word to guess:");
        
        String displayWord = "";
        char guess;
        int length = word.length();
        int rLength = length -1;
        Boolean guessed = false;
        Boolean reachedLimit = false;
       
        //use for loop to make the word with underscores that will update as the user guesses
        for (int j = 0; j!=length; j++){
            if(j <length){
            displayWord = displayWord + "_ ";
            }
        }
        //use while loop to check if user has reacher 10 wrong guesses or guesses the word correctly
        while((!guessed)&&(numberWrong<10)){ 
            
            System.out.println(displayWord);
        System.out.println("Guess a letter");
        guess = scnr.next().charAt(0);
        String guess2 = ""+guess;
        guess2 = guess2.toLowerCase();
        //make sure to ignore cases in case user has caps on 
            if(!word.toLowerCase().contains(guess2.toLowerCase())){
                numberWrong++;
                System.out.println("Guesses wrong: "+numberWrong);
                if(numberWrong ==10){
                    reachedLimit = true;
                }
                
            } 
            else if(word.toLowerCase().contains(guess2.toLowerCase())){
                for(int b =0; b<=rLength; b++){
                    String toCompare = word.substring(b,b+1);
                    //display word with proper casing hence the two ifs to check if the letter is first in the word causing it to be upper case
                    if((guess2.equalsIgnoreCase( toCompare))&&(b==0)){
                        displayWord = displayWord.substring(0,2*b)+ guess2.toUpperCase()+ displayWord.substring(b*2 +1);
                    }
                    if((guess2.equalsIgnoreCase( toCompare))&&(b>0)){
                        displayWord = displayWord.substring(0,2*b)+ guess2.toLowerCase()+ displayWord.substring(b*2 +1);
                    }
                    
                }
            }
            //check if word is correct by seeing if there is any underscores (gaps)left in the display word
            if (!displayWord.contains("_")){
                guessed = true;
            }
        }
        //check to see if word is not guessed correctly if reachedLimit is true
        if(reachedLimit){
            System.out.println("You lost! The word was "+word+".");
        }
        //check if word is guessed correctly by seeing if the boolean guessed is true
        if (guessed){
            System.out.println(word);
            System.out.println("You win!");
        }
    }
    
}
